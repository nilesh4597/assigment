$('.blog-grid-wrap').slick({
    infinite: true,
    dots: true,
    arrows: false,
    slidesToShow: 3,
    centerPadding: 10,
    slidesToScroll: 3,
    responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
    ]
});

$(document).ready(function() {
    var body = $('body');
if (body.length) {
    $(document).on("scroll", onScroll);

    //smoothscroll
    $('.menu a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        $(document).off("scroll");

        $('a').each(function() {
            $(this).removeClass('active');
        })
        $(this).addClass('active');

        var target = this.hash,
            menu = target;
        $target = $(target);
        $('html, body').stop().animate({
            'scrollTop': $target.offset().top + 2
        }, 500, 'swing', function() {
            window.location.hash = target;
            $(document).on("scroll", onScroll);
        });
    });
    }
});


function onScroll(event) {
    var scrollPos = $(document).scrollTop();
    $('.menu a').each(function() {
        var currLink = $(this);
        var refElement = $(currLink.attr("href"));
        if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $(' .menu  li a').removeClass("active");
            currLink.addClass("active");
        } else {
            currLink.removeClass("active");
        }
    });
}

if ($(window).width() > 767) {
    $(window).scroll(function() {
        var iCurScrollPos = $(this).scrollTop();
        if (iCurScrollPos > 40) {
            $("#header").addClass("active");

        } else {
            $("#header").removeClass("active");
        }
        
    });
    $(window).scroll()
}

$('#menu-icon').click(function() {
    $(this).toggle0Class('open');
    $('.menu').slideToggle();
});

if ($(window).width() < 767) {
    $('.menu li a').click(function() {
        $('#menu-icon').removeClass('open');
        $('.menu').slideUp();
    });
}